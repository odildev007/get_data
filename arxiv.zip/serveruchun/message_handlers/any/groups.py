from aiogram.types import Message

async def group_message_answer(message: Message):
    pass