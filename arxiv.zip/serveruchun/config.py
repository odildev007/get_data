TOKEN = "7078088437:AAG9lHMsj5qUcACXGh9nglD5MArUu_rfY1s"
ADMINS = [5165396993, 1259358144]
channel_id = -1001614320400
channel_url = "https://t.me/fizika_oson"